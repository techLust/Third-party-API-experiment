import React from "react";

const PokemonData = ({ PokemonData }) => {
  return <div>console.log(pokemonDatas)</div>;
};

export default PokemonData;
